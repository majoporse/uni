#include <stdio.h>
#include <stdlib.h>

void fill_matrix(int min_value, int max_value, size_t mrows, size_t mcols, int matrix[mrows][mcols]);
void print_matrix(size_t mrows, size_t mcols, int matrix[mrows][mcols]);
int find_max_min_in_array(size_t length, int *array, int *max, int *min);
void multiply_matrix(size_t mrows, size_t mcols, int matrix[mrows][mcols], int number);
int find_max_min_pointers(size_t, int*, int*, int*)
int main(void)
{
    int matrix[5][5];
    int max = 0, min = 0;
//    printf("matrix is pointing to %p with size of %zu\n",(void*) &matrix, sizeof(matrix));
//    printf("matrix[0] is pointing to %p with size of %zu\n",(void*) &matrix[0], sizeof(matrix[0]));
//    printf("matrix[1] is pointing to %p with size of %zu\n",(void*) &matrix[1], sizeof(matrix[1]));
//    printf("matrix[1][1] is pointing to %p with size of %zu\n",(void*) &matrix[1][1], sizeof(matrix[1][1]));
//    fill_matrix(0,5,5,5,matrix);
//    print_matrix(5,5,matrix);
//    printf("\n");
//    multiply_matrix(5,5,matrix,2);
//    print_matrix(5,5,matrix);
//    find_max_min_in_array(sizeof(matrix)/sizeof(int),matrix,&max ,&min);

    return 0;
}
int find_max_min_pointers
int find_max_min_in_array(size_t length, int *array, int *max, int *min)
{

    for(int i = 0;i<length;++i){
        if (array[i] < *min)
            *min = array[i];
        if (array[i] > *max)
            *max = array[i];
    }
    printf("MIN: %d ", *min);
    printf("MAX: %d", *max);


}
void multiply_matrix(size_t mrows, size_t mcols, int matrix[mrows][mcols], int number)
{
    for(int i = 0;i<mrows;++i){
        for (int j = 0;j<mcols;++j){
            matrix[i][j] *= number;
        }
    }
}

void fill_matrix(int min_value, int max_value, size_t mrows, size_t mcols, int matrix[mrows][mcols])
{
    if (max_value <= min_value) {
        return;
    }

    for (size_t i = 0; i < mrows; i++) {
        for (size_t j = 0; j < mcols; j++) {
            matrix[i][j] = rand() % (max_value - min_value) + min_value;
        }
    }
}

void print_matrix(size_t mrows, size_t mcols, int matrix[mrows][mcols])
{
    for (size_t i = 0; i < mrows; i++) {
        for (size_t j = 0; j < mcols; j++) {
            printf("%d\t", matrix[i][j]);
        }
        printf("\n");
    }
}
