#include "minesweeper.h"
#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#define flag_bit 32
#define val_bits 15
#define reveal_bit 64
#define BOMBA 16

/* ************************************************************** *
 *                         HELP FUNCTIONS                         *
 * ************************************************************** */

bool is_set(uint16_t cell)
{
    return get_number(cell) >= 0;
}

bool is_empty(uint16_t cell)
{
    return (cell & val_bits) == 1;
}

bool is_numeric(char val)
{
    return val <= '8' && val >= '0';
}

bool is_flag(uint16_t cell)
{
    return (cell & flag_bit) == flag_bit;
}

bool is_mine(uint16_t cell)
{
    return (cell & BOMBA) == BOMBA;
}

bool is_revealed(uint16_t cell)
{
    return (cell & reveal_bit) == reveal_bit;
}

bool is_hidden(uint16_t cell)
{
    return !is_revealed(cell);
}

int get_number(uint16_t cell)
{
    return (cell & val_bits) - 1;
}

bool in_range(size_t rows, size_t cols, size_t row, size_t col, int x, int y)
{
    return ((row + x) < rows) && (col + y < cols);
}

uint16_t radar(size_t rows,
        size_t cols,
        uint16_t board[rows][cols],
        size_t row,
        size_t col,
        bool (*fun)(uint16_t))
{
    int res = 0;
    for (int x = -1; x < 2; ++x) {
        for (int y = -1; y < 2; ++y) {
            if (in_range(rows, cols, row, col, x, y) && fun(board[row + x][col + y]))
                ++res;
        }
    }
    return res;
}

/* ************************************************************** *
 *                         INPUT FUNCTIONS                        *
 * ************************************************************** */

bool set_cell(uint16_t *cell, char val)
{
    if (cell == NULL)
        return false;

    val = (char) toupper(val);
    switch (val) {
    case 'M':
        *cell = BOMBA + 1;
        return true;
    case '.':
        *cell = reveal_bit;
        return true;
    case 'X':
        *cell = 0;
        return true;
    case 'F':
        *cell = flag_bit + BOMBA + 1;
        return true;
    case 'W':
        *cell = flag_bit;
        return true;
    default:
        if (is_numeric(val)) {
            *cell = reveal_bit + val - '0' + 1;
            return true;
        }
    }
    return false;
}

int load_board(size_t rows, size_t cols, uint16_t board[rows][cols])
{
    for (size_t x = 0; x < rows; ++x) {
        for (size_t y = 0; y < cols; ++y) {
            int ch = getchar();
            if (ch == EOF)
                return -1;
            while (!set_cell(&board[x][y], (char) ch)) {
                ch = getchar();
                if (ch == EOF)
                    return -1;
            }
        }
    }

    return postprocess(rows, cols, board);
}

bool check_size(size_t rows, size_t cols)
{
    return (rows > 99 || rows < 3 || cols > 99 || cols < 3);
}

bool check_corners(size_t rows, size_t cols, uint16_t board[rows][cols])
{
    return (is_mine(board[0][0]) || is_mine(board[0][cols - 1]) || is_mine(board[rows - 1][0]) ||
            is_mine(board[rows - 1][cols - 1]));
}

bool check_around(size_t rows, size_t cols, uint16_t board[rows][cols], size_t x, size_t y)
{
    uint16_t around = radar(rows, cols, board, x, y, &is_mine);
    if (is_revealed(board[x][y]) && is_set(board[x][y]) && (get_number(board[x][y]) != around))
        return true;

    if (!is_set(board[x][y]))
        board[x][y] += around + 1;
    return false;
}

bool count_mines(size_t rows, size_t cols, uint16_t board[rows][cols], int *mines, bool check)
{
    for (size_t x = 0; x < rows; ++x) {
        for (size_t y = 0; y < cols; ++y) {
            if (check && check_around(rows, cols, board, x, y))
                return true;
            if (is_mine(board[x][y]))
                *mines += 1;
        }
    }
    return false;
}

int postprocess(size_t rows, size_t cols, uint16_t board[rows][cols])
{
    if (check_size(rows, cols))
        return -1;

    if (check_corners(rows, cols, board))
        return -1;

    int mines = 0;
    if (count_mines(rows, cols, board, &mines, true))
        return -1;

    if (mines == 0)
        return -1;

    return mines;
}

/* ************************************************************** *
 *                        OUTPUT FUNCTIONS                        *
 * ************************************************************** */

void print_row_line(size_t size)
{
    printf("   +");
    for (size_t i = 0; i < size; ++i) {
        printf("---+");
    }
    putchar('\n');
}

void print_header(size_t cols)
{
    printf("   ");
    for (size_t i = 0; i < cols; ++i) {
        if (i < 10)
            printf("  %lu ", i);
        else
            printf(" %lu ", i);
    }
    putchar('\n');
}

int print_board(size_t rows, size_t cols, uint16_t board[rows][cols])
{
    print_header(cols);
    print_row_line(cols);
    for (size_t x = 0; x < rows; ++x) {
        if (x < 10)
            printf(" %lu |", x);
        else
            printf("%lu |", x);
        for (size_t y = 0; y < cols; ++y) {
            char cell = show_cell(board[x][y]);
            switch (cell) {
            case 'M':
                printf(" M ");
                break;
            case 'X':
                printf("XXX");
                break;
            case 'F':
                printf("_F_");
                break;
            case ' ':
                printf("   ");
                break;
            default:
                printf(" %c ", cell);
                break;
            }
            putchar('|');
        }
        putchar('\n');
        print_row_line(cols);
    }
    return 0;
}

char show_cell(uint16_t cell)
{
    if (is_revealed(cell)) {
        if (is_mine(cell))
            return 'M';
        return (get_number(cell) > 0) ? (get_number(cell) + '0') : (' ');
    }

    else if (is_flag(cell))
        return 'F';

    else if (!is_revealed(cell))
        return 'X';

    return -1;
}

/* ************************************************************** *
 *                    GAME MECHANIC FUNCTIONS                     *
 * ************************************************************** */

int reveal_cell(size_t rows, size_t cols, uint16_t board[rows][cols], size_t row, size_t col)
{
    if (rows <= row || cols <= col)
        return -1;

    int res = reveal_single(&board[row][col]);

    if (res == 0 && is_empty(board[row][col])) {
        reveal_floodfill(rows, cols, board, row, col);
    }
    return res;
}

int reveal_single(uint16_t *cell)
{
    if (cell == NULL)
        return -1;
    if (is_revealed(*cell) || is_flag(*cell))
        return -1;
    *cell |= reveal_bit;
    if (is_mine(*cell))
        return 1;
    return 0;
}

void reveal_rec(size_t rows, size_t cols, uint16_t board[rows][cols], size_t row, size_t col)
{
    if (is_flag(board[row][col]) && !is_mine(board[row][col]))
        board[row][col] -= flag_bit;
    if (reveal_single(&board[row][col]) == 0 && is_empty(board[row][col])) {
        reveal_floodfill(rows, cols, board, row, col);
    }
}

void reveal_floodfill(size_t rows, size_t cols, uint16_t board[rows][cols], size_t row, size_t col)
{
    for (int x = -1; x < 2; ++x) {
        for (int y = -1; y < 2; ++y) {
            if (!(x == 0 && y == 0) && in_range(rows, cols, row, col, x, y)) {
                size_t new_row = row + x;
                size_t new_col = col + y;
                reveal_rec(rows, cols, board, new_row, new_col);
            }
        }
    }
}

int count(size_t rows, size_t cols, uint16_t board[rows][cols], bool (*fun)(uint16_t))
{
    int res = 0;
    for (size_t x = 0; x < rows; ++x) {
        for (size_t y = 0; y < cols; ++y) {
            if (fun(board[x][y]))
                res += 1;
        }
    }
    return res;
}

int flag_cell(size_t rows, size_t cols, uint16_t board[rows][cols], size_t row, size_t col)
{
    int mine_count = 0;
    count_mines(rows, cols, board, &mine_count, false);

    if (is_revealed(board[row][col]))
        return INT16_MIN;

    if (is_flag(board[row][col]))
        board[row][col] -= flag_bit;
    else
        board[row][col] += flag_bit;

    int flag_count = count(rows, cols, board, &is_flag);
    return mine_count - flag_count;
}

bool is_solved(size_t rows, size_t cols, uint16_t board[rows][cols])
{
    int mines = 0;
    count_mines(rows, cols, board, &mines, false);
    int revealed = count(rows, cols, board, &is_revealed);
    int total = (int) (rows * cols);
    return mines == total - revealed;
}

/* ************************************************************** *
 *                         BONUS FUNCTIONS                        *
 * ************************************************************** */
void fill_out(size_t size, uint16_t board[size], uint16_t val)
{
    for (size_t i = 0; i < size; ++i) {
        board[i] = val;
    }
}

bool is_corner(size_t rows, size_t cols, size_t pos)
{
    return pos == 0 || pos == rows * cols - 1 || pos == cols - 1 || pos == (rows - 1) * cols;
}

void place_mine(size_t rows, size_t cols, uint16_t board[rows * cols])
{
    size_t pos;
    do {
        pos = (size_t) (rand() % (rows * cols));
    } while (is_corner(rows, cols, pos) || is_mine(board[pos]));

    board[pos] = BOMBA;
}

int generate_random_board(size_t rows, size_t cols, uint16_t board[rows][cols], size_t mines)
{
    if (check_size(rows, cols) || mines > rows * cols - 4)
        return -1;
    fill_out(rows * cols, (uint16_t *) board, 0);
    for (; mines > 0; --mines) {
        place_mine(rows, cols, (uint16_t *) board);
    }
    return postprocess(rows, cols, board);
}

bool set_val(uint16_t *add, char val)
{
    if (val == 'X') {
        *add = 0;
        return true;
    }
    if (is_numeric(val)) {
        *add = reveal_bit + val - '0' + 1;
        return true;
    }
    return false;
}

bool setup_board(size_t rows, size_t cols, uint16_t board[rows][cols])
{
    char ch;
    for (size_t x = 0; x < rows; ++x) {
        for (size_t y = 0; y < cols; ++y) {
            ch = (char) toupper(getchar());
            if (ch == EOF)
                return false;
            while (!set_val(&board[x][y], ch)) {
                ch = (char) toupper(getchar());
                if (ch == EOF)
                    return false;
            }
        }
    }
    return true;
}

void flag_pos(uint16_t *cell)
{
    *cell |= flag_bit;
}

int flag_around(size_t rows, size_t cols, uint16_t board[rows][cols], size_t row, size_t col)
{
    uint16_t cell;
    int new = 0;
    for (int x = -1; x < 2; ++x) {
        for (int y = -1; y < 2; ++y) {
            cell = board[row + x][col + y];
            if (in_range(rows, cols, row, col, x, y) && is_hidden(cell) && !is_flag(cell)) {
                flag_pos(&board[row + x][col + y]);
                ++new;
            }
        }
    }
    return new;
}

int flag_mines(size_t rows, size_t cols, uint16_t board[rows][cols], size_t row, size_t col)
{
    uint16_t cell = get_number(board[row][col]);
    uint16_t mines = radar(rows, cols, board, row, col, &is_hidden);
    int new = 0;
    if (mines == cell)
        new += flag_around(rows, cols, board, row, col);

    return new;
}

int find_mines(size_t rows, size_t cols, uint16_t board[rows][cols])
{
    int mines = 0;
    if (!setup_board(rows, cols, board))
        return -1;

    for (size_t x = 0; x < rows; ++x) {
        for (size_t y = 0; y < cols; ++y) {
            if (is_revealed(board[x][y]) && get_number(board[x][y]) > 0) {
                mines += flag_mines(rows, cols, board, x, y);
            }
        }
    }
    return mines;
}

//int main()
//{
//
//    generate_random_board(5,5,board, 3);
//    print_board(5,5,board);
//    return 0;
//}
