#include <stdio.h>
#include <stdlib.h>

int arr_sum(int array[], int size)
{
    int sum = 0;
    for (int cur = 0; cur < size; cur++)
    {
        sum += array[cur];
    }
    return sum;
}

void print_arr(int arr[], int size)
{
    printf("array: [");
    for (int cur = 0; cur < size -1; cur++)
    {
        printf("%d, ", arr[cur]);
    }
    printf("%d]\n", arr[size-1]);
}

int find_max_in_array(int array[10])
{
    int max = array[0];
    for (int cur = 0; cur < 10; cur++)
    {
        if (max < array[cur]) max = array[cur];
    }
    return max;
}

int find_min_in_array(int array[10])
{
    int min = array[0];
    for (int cur = 0; cur < 10; cur++)
    {
        if (min > array[cur]) min = array[cur];
    }
    return min;
}

int gcd(int a, int b)
{
    while (a > 0 && b > 0)
    {
        if (a > b) a -= b;
        else
            b -= a;
    }
    return (a > 0) ? a : b;
}

int find_gcd_in_array(int arr[10])
{
    int result = arr[0];
    for (int i = 1; i < 10; i++)
    {
        result = gcd(arr[i], result);

        if(result == 1)
        {
            return 1;
        }
    }
    return result;
}

int find_max_min_in_array(int array[10], int* max, int* min)
{
    int mi = array[0];
    int ma = array[0];
    for (int cur = 0; cur < 10; cur++)
}

int main(void)
{
//    int arr[10];
//    int ch;
//    int i = 0;
//    printf("Zadejte 10 cislic: ");
//    for (int cur = 0; cur < 10; cur++)
//    {
//        scanf("%d ", &ch);
//        arr[i] = ch;
//        ++i;
//    }
//    printf("sucet %d\n", arr_sum(arr, 10));
//    print_arr(arr, 10);
//    printf("%d\n", find_max_in_array(arr));
//    printf("%d\n", find_min_in_array(arr));
//    printf("%d\n", arr_sum(arr, 10));
    printf("%d", gcd(4,12));
    return EXIT_SUCCESS;
}
