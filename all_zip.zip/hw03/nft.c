#include <stdlib.h>
#include <string.h>

#include "capture.h"

int main(int argc, char *argv[])
{
    if (argc != 5) {
        fprintf(stderr, "load_capture failed\n");
        return EXIT_FAILURE;
    }

    char *filename = argv[1];
    char *from = argv[2];
    char *to = argv[3];
    char *statistic = argv[4];

    struct capture_t capture;
    struct capture_t filtered;
    struct capture_t filtered2;
    bool error = false;

    uint8_t from_ip[4];
    uint8_t from_mask;
    sscanf(from,
            "%hhu.%hhu.%hhu.%hhu/%hhu",
            &from_ip[0],
            &from_ip[1],
            &from_ip[2],
            &from_ip[3],
            &from_mask);

    uint8_t to_ip[4];
    uint8_t to_mask;
    sscanf(to, "%hhu.%hhu.%hhu.%hhu/%hhu", &to_ip[0], &to_ip[1], &to_ip[2], &to_ip[3], &to_mask);

    if (to_mask > 32 || from_mask > 32) {
        fprintf(stderr, "%s", "mask error\n");
        return EXIT_FAILURE;
    }
    if (load_capture(&capture, filename) != 0) {
        fprintf(stderr, "%s", "load capture error\n");
        return EXIT_FAILURE;
    }
    if (filter_from_mask(&capture, &filtered, from_ip, from_mask) != 0) {
        fprintf(stderr, "%s", "filter_from error\n");
        destroy_capture(&capture);
        return EXIT_FAILURE;
    }
    if (filter_to_mask(&filtered, &filtered2, to_ip, to_mask) != 0) {
        fprintf(stderr, "%s", "filter_to error\n");
        destroy_capture(&capture);
        destroy_capture(&filtered);
        return EXIT_FAILURE;
    }

    if (strcmp("flowstats", statistic) == 0) {
        if (print_flow_stats(&filtered2) != 0) {
            error = true;
        }
    } else if (strcmp("longestflow", statistic) == 0) {
        if (print_longest_flow(&filtered2) != 0) {
            error = true;
        }
    } else
        error = true;

    destroy_capture(&capture);
    destroy_capture(&filtered);
    destroy_capture(&filtered2);
    if (error)
        return EXIT_FAILURE;
    return EXIT_SUCCESS;
}
