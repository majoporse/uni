#include "capture.h"
#include "stdlib.h"
#include <assert.h>
#include <string.h>

#define ERROR 1
#define IP_LENGTH 4
#define MICROSECONDS 0xA1B2C3D4
#define NANOSECONDS 0xA1B23C4D
#define MAX_MICROSECONDS 1000000
#define MAX_NANOSECONDS 1000000000

int load_capture(struct capture_t *capture, const char *filename)
{
    struct pcap_context context;

    if (init_context(&context, filename) == PCAP_LOAD_ERROR || capture == NULL) {
        return ERROR;
    }

    if (load_header(&context, &capture->pcap_header) == PCAP_LOAD_ERROR) {
        destroy_context(&context);
        return ERROR;
    }

    struct packet_t packet;
    int msg;
    struct packet_t *new_array;
    capture->packets = 0;
    capture->packet_array = NULL;

    while ((msg = load_packet(&context, &packet)) == PCAP_SUCCESS) {
        ++capture->packets;
        new_array = realloc(capture->packet_array, capture->packets * sizeof(struct packet_t));

        if (new_array == NULL) {
            --capture->packets;
            destroy_context(&context);
            destroy_capture(capture);
            destroy_packet(&packet);
            return ERROR;
        }

        capture->packet_array = new_array;
        capture->packet_array[capture->packets - 1] = packet;
    }

    if (msg == PCAP_LOAD_ERROR) {
        destroy_context(&context);
        destroy_capture(capture);
        return ERROR;
    }
    destroy_context(&context);
    return 0;
}

void destroy_capture(struct capture_t *capture)
{
    for (size_t packs = 0; packs < capture->packets; ++packs) {
        destroy_packet(&capture->packet_array[packs]);
    }
    free(capture->packet_array);
}

bool is_same_ip(struct packet_t packet, uint8_t const source_ip[4], uint8_t const destination_ip[4])
{
    return *(uint32_t *) packet.ip_header->src_addr == *(uint32_t *) source_ip &&
            *(uint32_t *) packet.ip_header->dst_addr == *(uint32_t *) destination_ip;
}

const struct pcap_header_t *get_header(const struct capture_t *const capture)
{
    return &capture->pcap_header;
}

struct packet_t *get_packet(const struct capture_t *const capture, size_t index)
{
    if (capture == NULL || index >= capture->packets)
        return NULL;
    return &capture->packet_array[index];
}

size_t packet_count(const struct capture_t *const capture)
{
    return capture->packets;
}

size_t data_transfered(const struct capture_t *const capture)
{
    size_t res = 0;
    for (size_t i = 0; i < capture->packets; ++i) {
        res += capture->packet_array[i].packet_header->orig_len;
    }
    return res;
}

enum filter
{
    protocol_filter,
    from_to,
    larger_than,
    filter_from,
    filter_to
};

struct filtering_unit
{
    enum filter type;
    uint8_t protocol;
    uint32_t size;
    uint8_t source_ip[4];
    uint8_t destination_ip[4];
    uint8_t mask;
};

uint8_t mask(uint8_t mask_length)
{
    uint8_t res = UINT8_MAX;
    res <<= 8 - mask_length;
    return res;
}

bool is_equal_ip(uint8_t ip1[4], uint8_t ip2[4], int mask_len)
{
    for (int i = 0; i < 4 && mask_len > 0; ++i) {
        uint8_t cur_mask = mask((mask_len > 8) ? (8) : (mask_len));
        if ((ip1[i] & cur_mask) != (ip2[i] & cur_mask))
            return false;
        mask_len -= 8;
    }
    return true;
}

bool protocol_fun(const struct packet_t *packet, uint8_t protocol)
{
    return packet->ip_header->protocol == protocol;
}

bool from_to_fun(const struct packet_t *packet, uint8_t source_ip[4], uint8_t destination_ip[4])
{
    return is_same_ip(*packet, source_ip, destination_ip);
}

bool larger_than_fun(const struct packet_t *packet, uint32_t size)
{
    return packet->packet_header->orig_len >= size;
}

bool from_or_to_fun(const struct packet_t *packet, uint8_t ip[4], uint8_t mask, bool from)
{
    return is_equal_ip(
            (from) ? (packet->ip_header->src_addr) : (packet->ip_header->dst_addr), ip, mask);
}

bool filter_fun(struct packet_t *packet, struct filtering_unit filter)
{
    switch (filter.type) {
    case (protocol_filter):
        return protocol_fun(packet, filter.protocol);
    case (from_to):
        return from_to_fun(packet, filter.source_ip, filter.destination_ip);
    case (larger_than):
        return larger_than_fun(packet, filter.size);
    case (filter_from):
        return from_or_to_fun(packet, filter.source_ip, filter.mask, true);
    case (filter_to):
        return from_or_to_fun(packet, filter.source_ip, filter.mask, false);
    default:
        return false;
    }
}

int filter_with(const struct capture_t *const original,
        struct capture_t *filtered,
        struct filtering_unit filter)
{
    struct packet_t *new_array;

    for (size_t i = 0; i < original->packets; ++i) {
        if (filter_fun(&original->packet_array[i], filter)) {
            ++filtered->packets;
            new_array = realloc(
                    filtered->packet_array, filtered->packets * sizeof(*filtered->packet_array));

            if (new_array == NULL) {
                --filtered->packets;
                destroy_capture(filtered);
                return -1;
            }

            filtered->packet_array = new_array;
            if (copy_packet(&original->packet_array[i],
                        &filtered->packet_array[filtered->packets - 1]) == PCAP_LOAD_ERROR) {
                --filtered->packets;
                destroy_capture(filtered);
                return -1;
            }
        }
    }
    return 0;
}

void set_capture(struct capture_t *filtered, const struct capture_t *const original)
{
    filtered->pcap_header = original->pcap_header;
    filtered->packet_array = NULL;
    filtered->packets = 0;
}

int filter_protocol(
        const struct capture_t *const original, struct capture_t *filtered, uint8_t protocol)
{
    set_capture(filtered, original);
    struct filtering_unit filter;
    filter.type = protocol_filter;
    filter.protocol = protocol;

    return filter_with(original, filtered, filter);
}

int filter_larger_than(
        const struct capture_t *const original, struct capture_t *filtered, uint32_t size)
{
    set_capture(filtered, original);
    struct filtering_unit filter;
    filter.type = larger_than;
    filter.size = size;

    return filter_with(original, filtered, filter);
}

int filter_from_to(const struct capture_t *const original,
        struct capture_t *filtered,
        uint8_t source_ip[4],
        uint8_t destination_ip[4])
{
    set_capture(filtered, original);
    struct filtering_unit filter;
    filter.type = from_to;
    memcpy(filter.source_ip, source_ip, IP_LENGTH * sizeof(*source_ip));
    memcpy(filter.destination_ip, destination_ip, IP_LENGTH * sizeof(*destination_ip));

    return filter_with(original, filtered, filter);
}

int filter_with_mask(const struct capture_t *const original,
        struct capture_t *filtered,
        uint8_t network_prefix[4],
        uint8_t mask_length,
        bool from)
{
    set_capture(filtered, original);
    struct filtering_unit filter;
    filter.type = (from) ? (filter_from) : (filter_to);
    memcpy(filter.source_ip, network_prefix, IP_LENGTH * sizeof(*network_prefix));
    filter.mask = mask_length;

    return filter_with(original, filtered, filter);
}

int filter_from_mask(const struct capture_t *const original,
        struct capture_t *filtered,
        uint8_t network_prefix[4],
        uint8_t mask_length)
{
    return filter_with_mask(original, filtered, network_prefix, mask_length, true);
}

int filter_to_mask(const struct capture_t *const original,
        struct capture_t *filtered,
        uint8_t network_prefix[4],
        uint8_t mask_length)
{
    return filter_with_mask(original, filtered, network_prefix, mask_length, false);
}

struct flow
{
    size_t flows;
    uint8_t src_addr[4];
    uint8_t dst_addr[4];
    uint32_t start_sec;
    uint32_t start_usec;
    uint32_t end_sec;
    uint32_t end_usec;
};

struct flow_array
{
    struct flow **array;
    size_t length;
    struct flow *longest_flow;
    uint32_t max_sec;
    int64_t max_usec;
    uint32_t magic_number;
};

void destroy_flow_array(struct flow_array *array)
{
    for (size_t i = 0; i < array->length; ++i) {
        free(array->array[i]);
    }
    free(array->array);
}

void fix_time(struct flow *flow, struct packet_t *packet)
{
    uint32_t sec_stime_old = flow->start_sec;
    uint32_t usec_stime_old = flow->start_usec;

    uint32_t sec_time_new = packet->packet_header->ts_sec;
    uint32_t usec_time_new = packet->packet_header->ts_usec;

    if (sec_time_new < sec_stime_old ||
            (sec_stime_old == sec_time_new && usec_time_new < usec_stime_old)) {
        flow->start_sec = sec_time_new;
        flow->start_usec = usec_time_new;
    }

    uint32_t sec_etime_old = flow->end_sec;
    uint32_t usec_etime_old = flow->end_usec;

    if (sec_time_new > sec_etime_old ||
            (sec_etime_old == sec_time_new && usec_time_new > usec_etime_old)) {
        flow->end_sec = sec_time_new;
        flow->end_usec = usec_time_new;
    }
}

void fill_flow(struct flow_array *array, struct packet_t *packet, bool check_time)
{
    struct flow *flow = array->array[array->length - 1];

    flow->flows = 1;

    memcpy(flow->src_addr, packet->ip_header->src_addr, sizeof(packet->ip_header->src_addr));

    memcpy(flow->dst_addr, packet->ip_header->dst_addr, sizeof(packet->ip_header->dst_addr));

    if (check_time) {
        flow->start_sec = packet->packet_header->ts_sec;
        flow->start_usec = packet->packet_header->ts_usec;
        flow->end_sec = packet->packet_header->ts_sec;
        flow->end_usec = packet->packet_header->ts_usec;
    }
}

bool make_place(struct flow_array *array)
{
    array->length += 1;
    struct flow **new_array = realloc(array->array, array->length  * sizeof(struct flow *));
    if (new_array == NULL) {
        array->length -= 1;
        return false;
    }

    array->array = new_array;
    struct flow *new_flow = malloc(sizeof(struct flow));

    if (new_flow == NULL) {
        array->length -= 1;
        return false;
    }

    array->array[array->length - 1] = new_flow;

    return true;
}

bool place_packet(struct flow_array *array, struct packet_t *packet, bool check_time)
{
    for (size_t i = 0; i < array->length; ++i) {
        if (*(uint32_t *) array->array[i]->src_addr == *(uint32_t *) packet->ip_header->src_addr &&
                *(uint32_t *) array->array[i]->dst_addr ==
                        *(uint32_t *) packet->ip_header->dst_addr) {
            array->array[i]->flows += 1;
            if (check_time) {
                fix_time(array->array[i], packet);
            }
            return true;
        }
    }

    if (!make_place(array))
        return false;

    fill_flow(array, packet, check_time);
    return true;
}

bool find_flows(const struct capture_t *const capture, struct flow_array *array, bool check_time)
{
    for (size_t i = 0; i < capture->packets; ++i) {
        if (!place_packet(array, &capture->packet_array[i], check_time)) {
            destroy_flow_array(array);
            return false;
        }
    }
    return true;
}

int print_flow_stats(const struct capture_t *const capture)
{
    struct flow_array stats = { NULL, 0, NULL, 0, 0, capture->pcap_header.magic_number };
    if (!find_flows(capture, &stats, false)) {
        fprintf(stderr, "an error occured");
        return ERROR;
    }
    for (size_t i = 0; i < stats.length; ++i) {
        struct flow *cur = stats.array[i];
        printf("%u.%u.%u.%u ->",
                cur->src_addr[0],
                cur->src_addr[1],
                cur->src_addr[2],
                cur->src_addr[3]);
        printf(" %u.%u.%u.%u : ",
                cur->dst_addr[0],
                cur->dst_addr[1],
                cur->dst_addr[2],
                cur->dst_addr[3]);
        printf("%lu\n", cur->flows);
    }
    destroy_flow_array(&stats);
    return 0;
}

int print_longest_flow(const struct capture_t *const capture)
{
    struct flow_array stats = { NULL, 0, NULL, 0, 0, capture->pcap_header.magic_number };
    if (!find_flows(capture, &stats, true)) {
        fprintf(stderr, "%s", "an error occured");
        return ERROR;
    }
    uint32_t start;
    uint32_t start_usec;
    uint32_t end;
    uint32_t end_usec;
    int64_t max = (stats.magic_number == MICROSECONDS) ? (MAX_MICROSECONDS) : (MAX_NANOSECONDS);

    if (stats.length == 0) {
        fprintf(stderr, "%s", "NUMBER OF PACKETS IS 0");
        return ERROR;
    }

    for (size_t i = 0; i < stats.length; ++i) {
        start = stats.array[i]->start_sec;
        start_usec = stats.array[i]->start_usec;

        end = stats.array[i]->end_sec;
        end_usec = stats.array[i]->end_usec;

        int64_t delta_usec = (int32_t) end_usec - (int32_t) start_usec;
        uint32_t delta_sec = end - start;

        if (delta_usec < 0) {
            delta_sec -= 1;
            delta_usec = max + delta_sec;
        }

        if (delta_sec > stats.max_sec ||
                (delta_sec == stats.max_sec && delta_usec > stats.max_usec)) {
            stats.max_sec = delta_sec;
            stats.max_usec = delta_usec;
            stats.longest_flow = stats.array[i];
        }
    }

    struct flow *result = stats.longest_flow;
    printf("%hhu.%hhu.%hhu.%hhu -> ",
            result->src_addr[0],
            result->src_addr[1],
            result->src_addr[2],
            result->src_addr[3]);
    printf("%hhu.%hhu.%hhu.%hhu : ",
            result->dst_addr[0],
            result->dst_addr[1],
            result->dst_addr[2],
            result->dst_addr[3]);
    printf("%u:%u - %u:%u\n",
            result->start_sec,
            result->start_usec,
            result->end_sec,
            result->end_usec);
    destroy_flow_array(&stats);
    return 0;
}
