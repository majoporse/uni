#include <ctype.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#define DIVISION_BY_ZERO 4
#define NO_NUMBER 3
#define SYNTAX_ERROR 1
#define OUT_OF_RANGE 2

uint64_t power(uint64_t base, uint64_t pow)
{
    uint64_t res = 1;
    while (pow > 0) {
        res *= base;
        --pow;
    }
    return res;
}

bool is_numeric(int ch)
{
    return (ch >= '0' && ch <= '9');
}

bool is_af(int ch)
{
    return (toupper(ch) >= 'A') && (toupper(ch) <= 'F');
}

bool is_hex(int ch)
{
    return is_numeric(ch) || is_af(ch);
}

bool is_correct(int base, int cur)
{
    switch (base) {
    case 16:
        return is_hex(cur);
    case 10:
        return is_numeric(cur);
    case 8:
        return cur <= '7' && cur >= '0';
    case 2:
        return cur <= '1' && cur >= '0';
    default:
        return false;
    }
}

void print_error_message(char *message)
{
    fprintf(stderr, "%s\n", message);
}

void print_bin(uint64_t num)
{
    printf("# ");
    uint64_t initial_mask = power(2, 63);
    while ((num & initial_mask) != initial_mask)
        initial_mask >>= 1;
    if (initial_mask > 0) {
        while (initial_mask > 0) {
            printf("%d", (num & initial_mask) > 0 ? (1) : (0));
            initial_mask >>= 1;
        }
    } else
        printf("0");
    putchar('\n');
}

void bit_rotation(uint64_t temp, uint64_t *accu, char direction)
{
    uint64_t rest = 0;

    switch (direction) {
    case 'r':
        temp %= 64;
        rest = *accu % power(2, temp);
        *accu >>= temp;
        rest <<= (64 - temp);
        *accu += rest;
        break;

    case 'l':
        temp %= 64;
        rest = (temp == 0) ? (0) : (*accu >> (64 - temp));
        *accu <<= temp;
        *accu += rest;
        break;

    default:
        break;
    }
}

void print_error(int error)
{
    switch (error) {
        //kvoli codestylu, ktory mame na pb071 tak sa mi to neda zmenit,
        //preformatuje sa mi to na takto , ako to je. ani mne to nepride najkrajsie ale tak co ¯\_(ツ)_/¯

    case SYNTAX_ERROR:
        print_error_message("Syntax error");
        break;
    case OUT_OF_RANGE:
        print_error_message("Out of range");
        break;
    case NO_NUMBER:
        print_error_message("Syntax error");
        break;
    case DIVISION_BY_ZERO:
        print_error_message("Division by zero");
        break;
    default:
        break;
    }
}

int get_val(int base, uint64_t *add, bool *new, int *error, int cur)
{
    *error = SYNTAX_ERROR;
    int num;
    if (cur == 'X' || cur == 'O' || cur == 'T')
        cur = getchar();

    while (is_hex(cur) || isspace(cur)) {
        cur = toupper(cur);

        if (!isspace(cur)) {
            if (is_correct(base, cur)) {
                num = cur - ((is_af(cur)) ? ('A' - 10) : '0');
                if ((base != 10) ? (*add > ULLONG_MAX / base) : (*add >= (ULLONG_MAX / base) && num > 5)) {
                    *error = OUT_OF_RANGE;
                    return cur;
                }
                *add = *add * base + num;
                *error = 0;
            } else {
                *new = true;
                *error = SYNTAX_ERROR;
                return cur;
            }
        }
        cur = getchar();
    }
    *new = true;
    return cur;
}

int get_num(uint64_t *accu, uint64_t *add, bool *new, int *error, uint64_t mem)
{
    int ch;
    int cur = getchar();
    while (isspace(cur))
        cur = getchar();
    switch (cur) {
        //tiez aj tu :]
    case 'm':
        *add = mem;
        return 'm';

    case 'T':
        print_bin(*accu);
        ch = get_val(2, add, new, error, cur);
        break;

    case 'O':
        printf("# %lo\n", *accu);
        ch = get_val(8, add, new, error, cur);
        break;

    case 'X':
        printf("# %lX\n", *accu);
        ch = get_val(16, add, new, error, cur);
        break;

    default:
        ch = get_val(10, add, new, error, cur);
        break;
    }
    return ch;
}

int do_operation(uint64_t *accu, bool *new, int *error, uint64_t mem, int operation)
{
    uint64_t temp = 0;
    int current = get_num(accu, &temp, new, error, mem);
    if (*error > 1) {
        return current;
    }

    switch (operation) {
    case 'P':
        *accu = temp;
        break;
    case '+':
        if (*accu > (ULLONG_MAX - temp)) {
            *error = OUT_OF_RANGE;
            break;
        }
        *accu += temp;
        break;
    case '-':
        if (*accu < temp) {
            *error = OUT_OF_RANGE;
            break;
        }
        *accu -= temp;
        break;
    case '*':
        if ((temp > 0) ? (*accu > ULLONG_MAX / temp) : false) {
            *error = OUT_OF_RANGE;
            break;
        }
        *accu *= temp;
        break;
    case '/':
        if (temp == 0) {
            *error = DIVISION_BY_ZERO;
            break;
        }
        *accu /= temp;
        break;
    case '<':
        if (temp > 63) {
            *error = OUT_OF_RANGE;
            break;
        }
        *accu <<= temp;
        break;
    case '>':
        if (temp > 63) {
            *error = OUT_OF_RANGE;
            break;
        }
        *accu >>= temp;
        break;

    case 'r':
        bit_rotation(temp, accu, 'r');
        break;

    case 'l':
        bit_rotation(temp, accu, 'l');
        break;

    case '%':
        if (temp == 0) {
            *error = DIVISION_BY_ZERO;
            break;
        }
        *accu %= temp;
        break;

    default:
        break;
    }
    if (*error == 0)
        printf("# %lu\n", *accu);
    return current;
}

bool calculate(void)
{
    // TODO: implement calculator
    int current;

    uint64_t accu = 0;
    uint64_t mem = 0;

    int error = 0;
    bool new = false;

    while ((new) ? (current != EOF) : (current = getchar()) != EOF) {
        if (new)
            new = false;

        switch (current) {
        case 'X':
            printf("# %lX\n", accu);
            break;

        case 'O':
            printf("# %lo\n", accu);
            break;

        case 'T':
            print_bin(accu);
            break;

        case ';':
            while ((current = getchar()) != '\n' && current != EOF) {
            }
            break;

        case 'N':
            accu = 0;
            printf("# %lu\n", accu);
            break;

        case 'M':
            mem += accu;
            break;

        case '=':
            printf("# %lu\n", accu);
            break;

        case 'R':
            mem = 0;
            break;

        default:
            if (current == '%' || current == 'l' || current == 'r' ||
                    current == '+' || current == '-' || current == '>' ||
                    current == '<' || current == '*' || current == '/' ||
                    current == 'P')
                current = do_operation(&accu, &new, &error, mem, current);
            else if (!isspace(current))
                error = SYNTAX_ERROR;
            break;
        }
        if (error > 0) {
            print_error(error);
            return false;
        }
    }

    return true;
}

int main(void)
{
    if (!calculate()) {
        return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;
}
