#include <stdio.h>
#include <string.h>
#include "stdint.h"

#include "list.h"
#include "list_utils.h"

uint32_t mask(uint8_t mask_length) {
    uint32_t res = 0;
    uint32_t i = 0;
    for (; i < mask_length; ++i) {
        res <<= 1;
        res += 1;
    }
    res <<= 32 - i;
    return res;
}

bool is_equal_ip(uint8_t ip1[4], uint8_t ip2[4], int mask_len) {
    for (int i = 0; i < 4 && mask_len > 0; ++i) {
        uint8_t cur_mask = mask((mask_len > 8) ? (8) : (mask_len));
        if ((ip1[i] & cur_mask) != (ip2[i] & cur_mask))
            return false;
        mask_len -= 8;
    }
    return true;
}

int main(void) {
    uint8_t a[4] = {127, 0, 2, 3};
    uint8_t b[4] = {127, 0, 0, 0};

    uint8_t x[4];
    sscanf("123.123.123.123","%cu.%cu.%cu.%cu",&x[0],&x[1],&x[2],&x[3]);
    uint32_t d = 5;
    uint32_t e = 100;
    long c = (long) d-e;
    if ((*(uint32_t *) a & mask(9)) == (*(uint32_t *) b & mask(9))) {
        printf("lol");
    }
    return 0;
}
