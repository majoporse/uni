#include <stdio.h>
#include <ctype.h>
#include <stdint.h>

void draw_line(int length, char fill)
{
    if (length > 0)
    {
        while (length != 0)
        {
            putchar(fill);
            length--;
        }
        putchar('\n');
    }
}

void draw_square(int size)
{
    for (int start = 0; start < size; start++)
    {
        draw_line(2*size, '#');
    }
}

void draw_rectangle (int a, int b, char fill)
{
    for (int start = 0; start < a; start++)
    {
        draw_line(2*b, fill);
    }
}

void draw_circle(int radius, char fill, char space)
{
    for (int y = 0; y <= 2*radius-1; y++)
    {
        for (int x = 0; x <= 2*radius-1; x++)
        {
            if ((x-radius+0.5)*(x-radius+0.5) + (y-radius+0.5)*(y-radius+0.5) <= (radius-0.5) * (radius-0.5))
            {
                putchar(fill);
                putchar(fill);
                putchar(fill);
            }
            else
            {
                putchar(space);
                putchar(space);
                putchar(space);
            }

        }
        putchar('\n');
    }
}

int main(void)
{
    uint64_t a;
    scanf("%lo",&a);
    printf("%lu",a);
//    scanf("%d", &x);
//    draw_line(x, '#');
//    printf("\n");
//    draw_square(x);
//    putchar('\n');
//
//    int a;
//    int b;
//    char fill;
//
//    scanf("%d %d %c", &a, &b, &fill);
//    printf("%d %d %c \n",a, b, fill);
//    draw_rectangle(a, b, fill);
//    draw_circle(10, '#', '.');
    return 0;
}
