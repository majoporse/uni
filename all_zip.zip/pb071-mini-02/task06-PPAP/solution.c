#include <stdio.h>
#include <stdlib.h>

/**
 * PPAP
 *
 * \author Marko Řeháček
 */

int main(void)
{
    for (int i = 1; i < 106; i++) {
        if (i % 3 == 0)
            printf("PenPineapple");

        if (i % 5 == 0)
            printf("ApplePen");

        if (i % 3 != 0 && i % 5 != 0)
            printf("%d", i);

        putchar(' ');
    }
    return EXIT_SUCCESS;
}
