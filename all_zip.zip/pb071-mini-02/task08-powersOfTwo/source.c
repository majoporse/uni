#include <stdio.h>
#include <stdlib.h>

/*
 * Minihomework 02: Powers of 2
 * ---------------
 * Author: Samuel Gorta
 * Email:  samuel.gorta@mail.muni.cz
 *
 * Please do NOT contact authors directly, use Discussions in IS MU instead.
 * Otherwise you might not get an answer.
 * ---------------
 * Write program, that prints first n powers of 2 separated by 1 space (also after last one is 1 space).
 * example output for n = 10: "1 2 4 8 16 32 64 128 256 512 "
 */

void powers_of_two(int n)
{
    // TODO: your solution here
}

// do not change following code!
int main(void)
{
    powers_of_two(10);
    powers_of_two(0);
    powers_of_two(19);
    powers_of_two(1);
    powers_of_two(11);
    return EXIT_SUCCESS;
}
