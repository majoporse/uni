#include <stdio.h>
#include <stdlib.h>

/**
 * Interval
 *
 * \author Samuel Gorta
 */

void interval(int from, int to)
{
    for (int i = from; i <= to; i++) {
        printf("%d ", i);
    }
}

int main(void)
{
    interval(1, 20);
    interval(10, 18);
    interval(13, 27);
    interval(42, 41);
    interval(68, 68);
    return EXIT_SUCCESS;
}
