#include <stdio.h>
#include <stdlib.h>

/**
 * Alphanumeric
 *
 * \author Roman Chrenšť
 */

void alphanumeric(int num)
{
    if ((num >= '1' && num <= '9') || (num >= 'A' && num <= 'Z') || (num >= 'a' && num <= 'z')) {
        printf("%c\n", num);
    } else {
        printf("%d\n", num);
    }
}

// do not change following code!
int main(void)
{
    alphanumeric(50);
    alphanumeric(100);
    alphanumeric(0);
    alphanumeric(1000);
    return EXIT_SUCCESS;
}
