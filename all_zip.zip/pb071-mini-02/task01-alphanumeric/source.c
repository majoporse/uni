#include <stdio.h>
#include <stdlib.h>

/*
 * Minihomework 02: alphanumeric
 * ---------------
 * Author: Roman Chrenšť
 * Email:  469253@mail.muni.cz
 *
 * Please do NOT contact authors directly, use Discussions in IS MU instead.
 * Otherwise you might not get an answer.
 * ---------------
 * Implement function alphanumeric, so that if a number has a corresponding value in ASCII, i.e. a digit
 * or a letter (1 - 9, a - z, A - Z), it prints out that character, otherwise it prints the same number.
 * Every character should be followed by a newline character right after it.
 */

void alphanumeric(int num)
{
    int a = 10;
    a += ++num;
    printf("%d\n",a);
}

// do not change following code!
int main(void) {
    int prom = 0;
    if (prom = 0) printf("Never printed");
    if (prom = 1) printf("Never say never!");
    if (1 = prom) // compilation error
        return 0;
}
