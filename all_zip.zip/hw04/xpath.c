#include "xpath.h"

#define HEADER_SIZE (2 * sizeof(size_t))

#define STRING(X) ((mchar *) (X + HEADER_SIZE))
#define RAW(X) ((char *) (X - HEADER_SIZE))
#define LENGTH(X) ((size_t *) (RAW(X)))[0]
#define CAPACITY(X) ((size_t *) (RAW(X)))[1]

#define STDIN NULL
#define STDOUT NULL

/*****************************************************************************
 *  PRINTING
 *****************************************************************************/
void print_text(struct node *node, FILE *file_out)
{
    if (node->children == NULL)
        fprintf((file_out == STDOUT) ? stdout : file_out, "%s\n", node->text);
    else {
        for (size_t y = 0; y < vec_size(node->children); ++y) {
            print_text(*((struct node **) vec_get(node->children, y)), file_out);
        }
    }
}

void indent(FILE *file_out, size_t layer)
{
    for (size_t i = 0; i < layer; ++i) {
        fputc(' ', (file_out == STDOUT) ? stdin : file_out);
    }
}

void print_xml(struct node *node, FILE *file_out, size_t layer)
{
    indent(file_out, layer);

    //attributes
    fprintf((file_out == STDOUT) ? stdin : file_out, "<%s", node->name);
    char *att = NULL;
    char *val = NULL;
    if (node->keys != NULL) {
        for (size_t i = 0; i < vec_size(node->keys); ++i) {
            att = *((char **) vec_get(node->keys, i));
            val = *((char **) vec_get(node->values, i));
            fprintf((file_out == STDOUT) ? stdin : file_out, " %s=\"%s\"", att, val);
        }
    }

    //print content
    if (node->children == NULL && node->text == NULL) {
        fprintf((file_out == STDOUT) ? stdout : file_out, "/>\n");
        return;
    }

    else if (node->children == NULL)
        fprintf((file_out == STDOUT) ? stdout : file_out, ">%s", node->text);

    else {
        fprintf((file_out == STDOUT) ? stdout : file_out, ">\n");

        for (size_t y = 0; y < vec_size(node->children); ++y) {
            print_xml(*((struct node **) vec_get(node->children, y)), file_out, layer + 1);
        }
        indent(file_out, layer);
    }

    //print end tag
    fprintf((file_out == STDOUT) ? stdin : file_out, "</%s>\n", node->name);
}

bool print_found(struct vector *found, size_t layer, char *filename_out, enum output_type out_t)
{
    FILE *file = stdout;

    if (filename_out != STDIN) {
        file = fopen(filename_out, "w");
        if (file == NULL) {
            fprintf(stderr, "cannot write to a file\n");
            return false;
        }
    }

    if (out_t == XML && vec_size(found) > 1) {
        layer += 1;
        fprintf(file, "<result>\n");
    }

    for (size_t i = 0; i < vec_size(found); ++i) {
        struct node *cur = *((struct node **) vec_get(found, i));
        if (out_t == XML)
            print_xml(cur, file, layer);
        else
            print_text(cur, file);
    }

    if (out_t == XML && vec_size(found) > 1)
        fprintf(file, "</result>\n");

    if (filename_out != STDOUT)
        fclose(file);

    return true;
}

/*****************************************************************************
 *  MISC
 *****************************************************************************/

bool is_name(char cur)
{
    return isalpha(cur) || cur == '_' || cur == '-' || cur == '.' || cur == ':';
}

bool is_text(char cur)
{
    return cur != '\'' && cur != '\"' && cur != '&' && cur != '>' && cur != '<';
}

bool is_digit(char cur)
{
    return cur <= '9' && cur >= '0';
}

char *get_string(char **p_tree, bool (*predicate)(char))
{
    char *tree = *p_tree;
    size_t buff_size = 10;
    char *tmp = NULL;
    char *res = calloc(1, buff_size);
    size_t cur_size = 1;
    size_t i = 0;

    for (; predicate(tree[i]); ++i) {
        if (i == (cur_size * buff_size) - 2) {
            ++cur_size;
            tmp = calloc(1, cur_size * buff_size);
            memcpy(tmp, res, buff_size);
            free(res);
            if (tmp == NULL) {
                return NULL;
            }
            res = tmp;
        }
        res[i] = tree[i];
    }
    res[i + 1] = '\0';
    *p_tree += i;
    return res;
}

int key_pos(struct node *node, char *key)
{
    char *cur_key = NULL;
    for (size_t pos = 0; pos < vec_size(node->keys); ++pos) {
        cur_key = *((char **) vec_get(node->keys, pos));
        if (strcmp(cur_key, key) == 0) {
            return (int) pos;
        }
    }
    return -1;
}

bool correct_tree(char *search_tree)
{
    while (search_tree[0] != '\0') {
        if (search_tree[0] == '/') {
            ++search_tree;
            char *name = get_string(&search_tree, is_name);
            if (name[0] == '\0') {
                free(name);
                return false;
            }
            free(name);
            if (search_tree[0] == '[') {
                ++search_tree;
                if (search_tree[0] == '@') {
                    ++search_tree;
                    char *att_name = get_string(&search_tree, is_name);
                    if (att_name[0] == '\0') {
                        free(att_name);
                        return false;
                    }
                    free(att_name);
                    if (search_tree[0] == '=' && search_tree[1] == '"') {
                        search_tree += 2;
                        char *val = get_string(&search_tree, is_text);
                        if (val[0] == '\0') {
                            free(val);
                            return false;
                        }
                        free(val);
                        if (search_tree[0] != '"')
                            return false;
                        ++search_tree;
                    }
                    if (search_tree[0] != ']')
                        return false;
                    ++search_tree;

                } else {
                    int num = -1;
                    char *num_str = get_string(&search_tree, is_digit);
                    sscanf(num_str, "%d", &num);
                    if (num_str[0] == '\0' || num <= 0) {
                        free(num_str);
                        return false;
                    }
                    free(num_str);
                    if (search_tree[0] != ']')
                        return false;
                    ++search_tree;
                }
            }
        } else
            return false;
    }
    return true;
}
/*****************************************************************************
 *  SEARCHING
 *****************************************************************************/

void search_attribute_val(
        struct node *node, char **search_tree, char *name, char *att_name, struct vector *found)
{
    char *val = get_string(search_tree, is_text);
    if (val == NULL || !(*search_tree[0] == '"' || *search_tree[1] != ']')) {
        free(val);
        return;
    }
    *search_tree += 2;

    if (node->children == NULL)
        return;

    for (size_t i = 0; i < vec_size(node->children); ++i) {
        struct node *cur = *((struct node **) vec_get(node->children, i));

        int position = key_pos(cur, att_name);
        if (position == -1) {
            free(val);
            return;
        }

        char *cur_val = *((char **) vec_get(cur->values, position));
        char *cur_name = *((char **) vec_get(cur->keys, position));

        if (strcmp(cur_val, val) == 0 && strcmp(cur_name, att_name) == 0 &&
                strcmp(cur->name, name) == 0)
            search(cur, *search_tree, found);
    }
    free(val);
}

void search_names(struct node *node, char *search_tree, char *name, struct vector *found)
{
    struct node *cur = NULL;
    if (node->children == NULL)
        return;

    for (size_t i = 0; i < vec_size(node->children); ++i) {
        cur = *((struct node **) vec_get(node->children, i));

        if (strcmp(cur->name, name) == 0)
            search(cur, search_tree, found);
    }
}

void search_attribute_key(
        struct node *node, char *search_tree, char *name, char *att_name, struct vector *found)
{
    if (node->children == NULL)
        return;

    for (size_t i = 0; i < vec_size(node->children); ++i) {
        struct node *cur = *((struct node **) vec_get(node->children, i));

        if (key_pos(cur, att_name) != -1 && strcmp(cur->name, name) == 0)
            search(cur, search_tree, found);
    }
}

void search_nth_name(
        struct node *node, char *search_tree, char *name, size_t num, struct vector *found)
{
    if (node->children == NULL)
        return;

    for (size_t i = 0; i < vec_size(node->children); ++i) {
        struct node *cur = *((struct node **) vec_get(node->children, i));
        mchar *cur_name = cur->name;

        if (strcmp(name, cur_name) == 0 && num-- == 1)
            search(cur, search_tree, found);
    }
}

void search(struct node *node, char *search_tree, struct vector *found)
{
    if (search_tree[0] == '\0') {
        vec_push_back(found, &node);
        return;
    }

    char *name = NULL;
    char *attribute_name = NULL;
    size_t num;
    char *str_num = NULL;

    if (search_tree[0] != '/')
        return;
    ++search_tree;
    name = get_string(&search_tree, is_name);
    if (name[0] == '\0') {
        free(name);
        return;
    }

    if (search_tree[0] == '[') {
        ++search_tree;
        if (search_tree[0] == '@') {
            ++search_tree;

            attribute_name = get_string(&search_tree, is_name);

            if (search_tree[0] == '=' && search_tree[1] == '"') {
                search_tree += 2;
                search_attribute_val(node, &search_tree, name, attribute_name, found);

            } else {
                ++search_tree;
                search_attribute_key(node, search_tree, name, attribute_name, found);
            }
            free(attribute_name);

        } else {
            str_num = get_string(&search_tree, is_digit);

            sscanf(str_num, "%lu", &num);
            ++search_tree;
            search_nth_name(node, search_tree, name, num, found);
            free(str_num);
        }
    } else {
        search_names(node, search_tree, name, found);
    }

    free(name);
}
