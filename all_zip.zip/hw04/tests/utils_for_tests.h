int file_to_string(const char *, char **);

const char *_match_seek(const char *);

int match(const char *, const char *);
