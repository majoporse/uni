#ifndef XPATH_H
#define XPATH_H
#include <ctype.h>
#include <stdio.h>

#include "managed_string.h"
#include "vector.h"
#include "xparser.h"

enum output_type
{
    TEXT,
    XML,
    NOT_SPECIFIED
};

void search(struct node *node, char *search_tree, struct vector *found);

void print_text(struct node *node, FILE *file_out);

void print_xml(struct node *node, FILE *file_out, size_t layer);

bool print_found(struct vector *found, size_t layer, char *filename_out, enum output_type out_t);

char *load_input();

char *get_string(char **p_tree, bool (*predicate)(char));

bool is_name(char cur);

bool is_text(char cur);

bool is_digit(char cur);

bool correct_tree(char *search_tree);

#endif /* XPATH_H */
