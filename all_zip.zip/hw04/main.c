#include "xpath.h"

#define STDIN NULL
#define STDOUT NULL

/*****************************************************************************
 *  ARGUMENTS
 *****************************************************************************/

bool handle_args(int argc,
        char **argv,
        char **file_in,
        char **file_out,
        enum output_type *out_t,
        char **search_tree)
{
    for (int i = 1; i < argc; ++i) {
        if (strcmp(argv[i], "-i") == 0 || strcmp(argv[i], "--input") == 0) {
            if (*file_in != STDIN) {
                fprintf(stderr, "invalid arguments\n");
                return false;
            }
            ++i;
            if (i >= argc) {
                fprintf(stderr, "missing input specifier\n");
                return false;
            }

            *file_in = argv[i];

        } else if (strcmp(argv[i], "-o") == 0 || strcmp(argv[i], "--output") == 0) {
            if (*file_out != STDOUT) {
                fprintf(stderr, "invalid arguments\n");
                return false;
            }
            ++i;
            if (i >= argc) {
                fprintf(stderr, "missing output specifier\n");
                return false;
            }

            *file_out = argv[i];

        } else if (strcmp(argv[i], "-t") == 0 || strcmp(argv[i], "--text") == 0) {
            if (*out_t != NOT_SPECIFIED) {
                fprintf(stderr, "cannot mix both -t and -x\n");
                return false;
            }
            *out_t = TEXT;

        } else if (strcmp(argv[i], "-x") == 0 || strcmp(argv[i], "--xml") == 0) {
            if (*out_t != NOT_SPECIFIED) {
                fprintf(stderr, "cannot mix both -t and -x\n");
                return false;
            }
            *out_t = XML;
        } else {
            if (i == argc - 1)
                *search_tree = argv[i];
            else {
                fprintf(stderr, "invalid arguments\n");
                return false;
            }
        }
    }
    return true;
}

int main(int argc, char **argv)
{
    char *filename_in = STDIN;
    char *filename_out = STDOUT;
    enum output_type out_t = NOT_SPECIFIED;
    char *search_tree = NULL;
    FILE *file_p_in = NULL;

    if (!handle_args(argc, argv, &filename_in, &filename_out, &out_t, &search_tree))
        return EXIT_FAILURE;

    if (search_tree == NULL || !correct_tree(search_tree)) {
        if (search_tree == NULL)
            fprintf(stderr, "path not specified\n");
        else
            fprintf(stderr, "wrong path\n");
        return EXIT_FAILURE;
    }

    if (filename_in != NULL) {
        file_p_in = fopen(filename_in, "r");
        if (file_p_in == NULL) {
            fprintf(stderr, "cannot open file\n");
            return EXIT_FAILURE;
        }
    }

    struct file_generator f_data = { (filename_in == STDIN) ? stdin : file_p_in };
    struct parsing_state ps = parsing_state_init(&f_data, file_fill);

    //parsing
    struct node *root = parse_root(&ps);
    if (root == NULL) {
        print_error(&ps, stderr);
        if (filename_in != STDIN) {
            fclose(file_p_in);
        }
        return EXIT_FAILURE;
    }

    if (filename_in != STDIN) {
        fclose(file_p_in);
    }

    //searching

    struct vector *found = vec_create(sizeof(struct node *));
    struct vector *search_vec = vec_create(sizeof(struct node *));
    vec_push_back(search_vec, &root);
    char *search_name = str_create("search_node");
    struct node *search_node = node_create(search_name, NULL, NULL, NULL, search_vec);

    search(search_node, search_tree, found);

    //printing
    print_found(found, 0, filename_out, out_t);

    node_destroy(search_node);
    free(found->data);
    free(found);

    //    puts("Hard times create strong men.");

    return EXIT_SUCCESS;
}
